# animals and people > 2025-01-05 5:37pm
https://universe.roboflow.com/danilo-f8uue/animals-and-people

Provided by a Roboflow user
License: CC BY 4.0

